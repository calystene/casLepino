<?php
try
{
    echo 'ok';
    $bdd = new PDO("pgsql:host=localhost; dbname=cdaw2012","casLepino","CDAW");
    $bdd ->query("SET NAMES UTF8");
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}
?>
