<?php 


/* La classe User sert � stocker les informations de l'utilisateur suite � son authentification */
class User {

//attributs
private $num_resp;
private $nom;
private $prenom;
private $login;


//m�thodes
public function __construct($num, $nom, $prenom, $login) {
  $this->num_rep = $num;
  $this->nom = $nom;
  $this->prenom = $prenom;
  $this->login = $login;
}

public function getNum() {
  return $this->num_resp;
}

public function getNom() {
  return $this->nom;
}

public function getNomEcho() {
  echo $this->nom;
}

public function getPrenom() {
  return $this->prenom;
}

public function getPrenomEcho() {
  echo $this->prenom;
}

public function getLogin() {
  return $this->login;
}
  
public function getLoginEcho() {
  echo $this->login;
}

}





?>