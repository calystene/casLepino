
<div id="bg">
  <div id="header">
    <!-- Tête de la page-->
    <div id="loggin">
      <?php include('./include/private/form_auth.php'); ?>
      
    </div>
    <div id="nav">
      <h1>
	<a href="#"> CapLepino </a>
      </h1>
      <br class="clear" />
    
    
    </div>
    

  </div>

