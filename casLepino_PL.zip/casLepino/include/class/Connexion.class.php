<?php 

  class Connexion {
    
  
  
  }




?>