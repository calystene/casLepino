<?php 
 
$content = '';

if(!(isset($_POST['login']) && isset($_POST['pswd']))) { 
  $content .= '<form name="input" action="./index.php" method="post">';
  $content .= '<table cellspacing=0><tr>';
  $content .= '<td>Login :</td><td> <input type="text" name="login" value="" /></td>';
  $content .= '<td rowspan=2><input type="button" value="Valider" /></td></tr>';
  $content .= '<tr><td>Password :</td><td> <input type="password" name="pwd" value="" /></td></tr>';
  $content .= '</table>';
  $content .= '</form>';
} else {
  authentification();
  $user = getUser();
  // && !isset($user)
  if($user!=false) {
    echo $user->getPrenom();
    echo $user->getNom();
    $content .= '<article>';
    $content .= '<h3>Bienvenue ' .$user->getPrenom().' '.$user->getNom().'</h3><br>';
    $content .= '</article>';
  } else {
    $content .= '<article>';
    $content .= '<h3>Petit probl�me d\'authentification</h3><br>';
    $content .= '</article>';
  }
}

echo $content;
?>
