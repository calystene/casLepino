<?php
require_once('./include/class/User.class.php');


function connexion() {
  try
  {
      $connexion = new PDO("pgsql:host=localhost; dbname=hequet","hequet","Gmail321");
      $connexion ->query("SET NAMES UTF8");
  
  }
  catch (Exception $e) {
	  die('Erreur : ' . $e->getMessage());
	  exit();
  }
}
  
function authentification() {
session_start();

try
  {
      $connexion = new PDO("pgsql:host=localhost; dbname=hequet","hequet","Gmail321");
      $connexion ->query("SET NAMES UTF8");
  
  }
  catch (Exception $e) {
	  die('Erreur : ' . $e->getMessage());
	  //exit();
  }

      if($connexion!=null && !isset($_SESSION['user']) && isset($_POST['login']) && isset($_POST['pswd'])) {
	
	$log = $_POST['login'];
	$mdp = $_POST['pswd'];
	  
	$stmt = $connexion->prepare("SELECT num_resp, nom, prenom, login FROM responsable WHERE login=".$log." AND password=".$mdp.";");
	$stmt->execute();
	$stmt->setFetchMode(PDO::FETCH_ASSOC);
	
	$nfo = $stmt->fetch();
	
	$_SESSION['user'] = new User($nfo['num_resp'], $nfo['nom'], $nfo['prenom'], $nfo['login']);
      }
}
  
  
function deconnexion() {
    session_destroy();
}
  
  
function getUser() {
  if(isset($_SESSION['user'])) {
    return $_SESSION['user'];
  } else {
    return false;
  }
}
?>
