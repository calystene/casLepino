
      <div id="outer">
	<div id="main">
	  <!-- Corps de la page --> 
		    <nav>  
		      <table>
			<tr>
			  <td><a href="index.php">Accueil</a></td>
			  <td><a href="produits.php">Produits</a></td>
			  <td><a href="compte.php">Compte</a></td>
			  <td><a href="http://www.lifl.fr/~mailliet/">Maman je t'aime</a></td>
			</tr>  
		      </table>
		    </nav>
	  <div id="sidebar2">
            
	  </div>
	  <div id="content">
		 
	    <div id="box1">
	      <div id="corps">
	      </div><br />
	      <p id="heure_serveur"> 
		Il est <span id="heure"> 
  <?php 
    date_default_timezone_set('UTC');
    echo Date('H:i:s'); 
  ?> 
  </span>
	      </p>
	    </div>
	    <div id="box1">
	    </div>
	  </div>
	  <br id="clear" />
	</div> 
	<br id="clear" />
      </div>
      <div id="copyright">
	<!-- Bas de page -->
	&copy; CasLepino | Made by Thomas Pierard and Pierre-Louis Hequet.
      </div>
    </div>
