<?php 
  require_once('./include/lib_connexion.php');

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
    <meta author="Pierard et Hequet" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <title>CasLepino</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>


<?php //require('include/connexion_BBD.php'); 

   
   include('./html/nav.php');
   include('./html/compte.php');

?>



  </body>
</hmtl>
